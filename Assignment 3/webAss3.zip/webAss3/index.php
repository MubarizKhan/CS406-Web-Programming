<!DOCTYPE html>
<html>
<head>
	<title> Log In | Notes </title>
</head>
<body>
	<h1> log In </h1>
	<form action="auth.php" method="GET">
		<input type="text"     name="username">
		<input type="password" name="userpass">
		<input type="submit"   name="" value="LogIn">
	</form>
</body>
</html>